// Basic client-side behaviour: show a small alert on contact form submit (demo)
document.addEventListener('DOMContentLoaded', function(){
  var f = document.getElementById('contactForm');
  if(f){
    f.addEventListener('submit', function(e){
      // Allow actual submit to go to Formspree; show a quick message
      alert('Thank you! Your message will be sent (demo). Replace the form endpoint with your Formspree ID or server endpoint.');
    });
  }
});

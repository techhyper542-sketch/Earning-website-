# EarnSmart — Static Website Template

## What this is
A simple static website template (HTML/CSS/JS) to help you start a site about earning money online. It's a demo and must be customized before use.

## Files
- index.html — Landing page
- earn.html — Methods and guides
- about.html — About the site
- contact.html — Contact form (demo)
- styles.css — Styles
- script.js — Small client-side script

## How to use
1. Unzip the package.
2. Edit HTML files to add your content, affiliate links, and real contact form endpoint.
3. Upload to any static hosting: Netlify, GitHub Pages, Vercel, Firebase Hosting, or a shared host.

## Monetization hints
- Affiliate marketing: sign up for affiliate programs and replace links with your affiliate IDs.
- Freelance services: create a clear services/pricing page and portfolio.
- Digital products: sell via Gumroad, SendOwl, or integrate Stripe for payments.
- Ads: apply to Google AdSense once your content and traffic meet their policies.
- Make sure to follow each platform's policies and local laws.

## Replace placeholders
- Change the contact form action (currently uses Formspree placeholder).
- Add real analytics (Google Analytics or Matomo) and ad network code only after you meet policies.
- Do NOT include misleading or get-rich-quick claims.

## License
This template is free to use and modify.

